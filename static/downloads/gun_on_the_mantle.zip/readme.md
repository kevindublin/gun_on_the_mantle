Thank you for downloading Gun on the Mantle by Kevin Dublin

When you are done playing, could you please fill out the survey at the link below?

https://forms.gle/L336B8Jz5Xt97eCT8

Here are some questions to have in mind while playing:


How many players were there?

How many minutes did it take to understand the rules?

How many minutes did it take you to play the game?

Which character card did the winner have?
>Scientist
>Hunter
>Athlete
>Hacker
>Inspector
>Teacher

How many turns were in your game?

Did anyone exchange a card?

Did you ever run out of coins?
>Yes
>No

Could you play the game again without looking at the rules?
>Yes
>No

Did this remind you of any other games?


How would you rank this game using the BGG (1-10) scale?

Why would you rank it at that position?


How enjoyable was the game?

Boring/Horrible
1
2
3
4
5
Fun/Interesting

How challenging was the game?
Very simple
1
2
3
4
5
Very challenging

How easy was it to predict the other player’s character card?
Very easy
1
2
3
4
5
Very difficult

How much luck did you feel was involved?
Too much luck
1
2
3
4
5
Too little luck

How much strategy did you feel was involved?
No strategy
1
2
3
4
5
Too much strategy

How long did the game feel?
Too long
1
2
3
4
5
Too short

How many players do you think would be ideal for this game?

What is your overall opinion of this game?

Any additional comments?

Thank you again for playtesting this game and taking this survey!

I hope you enjoy it!
